﻿// See https://aka.ms/new-console-template for more information


Console.WriteLine("Cricket Specialist in a format");

var player = new CricketSpecialistInAFormat();

player.OverAllRate(Source.XML);
