﻿// See https://aka.ms/new-console-template for more information


using Newtonsoft.Json;
using System.Xml.Serialization;

internal class CricketSpecialistInAFormat
{
    public int OverAllRating { get; set; }

    internal void OverAllRate(Source source)
    {

        List<CricketRating> ratingObject = new();
        if(Source.JSON == source)
        {
            var ratingJson = File.ReadAllText("C:\\Users\\611184113\\source\\repos\\SRP\\SRP\\cricket.json");
            ratingObject = JsonConvert.DeserializeObject<List<CricketRating>>(ratingJson);

        }
        else if (Source.XML == source)
        {
            string path = Path.Combine(Environment.CurrentDirectory, "cricket.xml");
            ratingObject =DeserializeToObject<List<CricketRating>>(path);

        }
        
        foreach (var item in ratingObject)
        {
            Console.WriteLine("-----------------------------");
            Enum.TryParse(item.Format, out CricketFormat format);
            switch (format)
            {
                case CricketFormat.T20:
                    Console.WriteLine("T20 Format");
                    if(item.StrikeRate > 150 && item.Average > 40)
                    {
                        Console.WriteLine($"star player:: {item.Name}");
                        Console.WriteLine("Applicable for special bonus");
                    }
                    else
                    {
                        Console.WriteLine($"Average player:: {item.Name}");
                        Console.WriteLine("player will be given next 10 chances to prove");
                        Console.WriteLine("Not applicable for bonus");
                    }
                    break;
                case CricketFormat.ODI:
                    Console.WriteLine("ODI Format");
                    if (item.StrikeRate > 95)
                    {
                        Console.WriteLine($"star player:: {item.Name}");
                        Console.WriteLine("Applicable for special bonus");
                    }
                    else
                    {
                        Console.WriteLine($"Average player:: {item.Name}");
                        Console.WriteLine("Not applicable for bonus");
                    }
                    break;
                default:
                    Console.WriteLine("unknown format!!");
                    break;
            } 
        }
    }

    public T DeserializeToObject<T>(string filepath) where T : class
    {
        XmlSerializer ser = new XmlSerializer(typeof(T));

        using (StreamReader sr = new StreamReader(filepath))
        {
            return (T)ser.Deserialize(sr);
        }
    }

    public T SerializeXml<T>(string filepath, T result) where T : class
    {
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));

        using (FileStream stream = File.Create(filepath))
        {
            xmlSerializer.Serialize(stream, result);
        }
        return result;
    }
}