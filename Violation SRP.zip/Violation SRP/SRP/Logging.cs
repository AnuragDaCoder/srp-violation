﻿
using Newtonsoft.Json;

public class Logger
{
    public void Log(string message)
    {
        Console.WriteLine(message);
    }
}

public class CricketStatsSource
{
    public string GetCricketStatsFromSource()
    {
        return File.ReadAllText("C:\\Users\\611184113\\source\\repos\\SRP\\SRP\\cricket.json");
    }
}

public class CricketRatingDeserializer
{
    public List<CricketRating> GetCricketStatsFromJsonSource(string stats)
    {
        return JsonConvert.DeserializeObject<List<CricketRating>>(stats);
    }

    public List<CricketRating> GetCricketStatsFromXMLSource(string stats)
    {
        return JsonConvert.DeserializeObject<List<CricketRating>>(stats);
    }
}